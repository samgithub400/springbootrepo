package com.ios;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootWithAwsApplicationTests {

	@Test
	void contextLoads() {
	}

}
